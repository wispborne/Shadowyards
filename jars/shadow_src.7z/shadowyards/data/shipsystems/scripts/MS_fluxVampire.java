/* Ship system script for the Poseidon
** Temporarily lowers max flux of an effected ship **
** Each ship effected is noted by a "drain pip" (up to five)
** every active pip */
package data.shipsystems.scripts;


public class MS_fluxVampire {
    
}

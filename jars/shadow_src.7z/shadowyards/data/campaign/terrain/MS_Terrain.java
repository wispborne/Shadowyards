package data.campaign.terrain;

public class MS_Terrain {
    
    public static final String ECHOES = "sensor_ghosts"; //Berin's Stash area effect, reduces sensor range, produces bad sensor readings
    public static final String INTENSE_MAGNETIC_FIELD = "super_magnetic"; //for calleach, magnetic field plus CR degredation
}

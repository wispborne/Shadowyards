package data.campaign.econ;

public class MS_specialItems {
    //autoforges
    public static final String DEGRADED_AUTOFORGE = "ms_degradedAutoforge";
    public static final String PERFECT_AUTOFORGE = "ms_perfectAutoforge";
    
    //fabricator upgrade consumables
    public static final String PARALLEL_TOOLING_PACKAGE = "ms_parallelTooling";
    public static final String MILITARY_LOGISTICS_UPGRADE = "ms_militaryLogistics";
    public static final String SPECIALIZED_SYSTEMS_FABRICATORS = "ms_specializedSystemsFabs";
}

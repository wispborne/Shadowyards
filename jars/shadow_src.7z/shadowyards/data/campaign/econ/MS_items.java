package data.campaign.econ;

public class MS_items {
    public static final String BATTERIES = "ms_hdbatteries";
    public static final String GUTS = "ms_clonedParts";
}

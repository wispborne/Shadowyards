package com.fs.starfarer.api.impl.campaign.intel;

import com.fs.starfarer.api.campaign.SectorEntityToken;


public class MS_RedwingsDepartureIntel extends BaseIntelPlugin {
    public static float MAX_DURATION = 90f;
    
    private SectorEntityToken source = null;
    private SectorEntityToken headingTo = null;
    
    
}

package com.fs.starfarer.api.impl.campaign.econ.impl;

public interface IndustryItemUser {
    public void applyItemEffects(String id);
    public void unapplyItemEffects();
}
